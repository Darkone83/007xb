//D:800XXXXX
MODELFILEHEADER(spooltape, 0, &SKELETON(standard_gun), 0, 0x1C, 3, 134.8334, 0, 2)

//included by propModelFileHeaders.inc.c to pobjdata.c
//touch pobjdata.c to recompile


MODELFILEHEADER(doorpanel, 0, &SKELETON(console_four_screen), 0, 0x4, 0x1, 338.28839, 0, 4)

//included by propModelFileHeaders.inc.c to pobjdata.c
//touch pobjdata.c to recompile


MODELFILEHEADER(console_sevb, 0, &SKELETON(console_one_screen), 0, 0x1, 0x1, 994.23688, 0, 0xB)

//included by propModelFileHeaders.inc.c to pobjdata.c
//touch pobjdata.c to recompile


MODELFILEHEADER(console_sev_GEa, 0, &SKELETON(standard_object), 0, 0, 1, 994.23688, 0, 0xD)

//included by propModelFileHeaders.inc.c to pobjdata.c
//touch pobjdata.c to recompile


MODELFILEHEADER(chrbombcase, 0, &SKELETON(prop_weapon), 0, 0x3, 0x1, 342.23688, 0, 5)

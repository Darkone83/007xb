//included by propModelFileHeaders.inc.c to pobjdata.c
//touch pobjdata.c to recompile


MODELFILEHEADER(door_st_arec2, 0, &SKELETON(standard_object), 0, 0, 1, 763.03589, 0, 3)
